﻿namespace CollegeManagement.DTO.MarksesDTO
{
    public class MarksListDTO
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public int SubjectID { get; set; }
        public string SubjectName { get; set; }
        public int Year { get; set; }
    }
}
