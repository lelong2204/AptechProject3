﻿namespace CollegeManagement.DTO.CourseDTO
{
    public class CourseSelectDTO
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
