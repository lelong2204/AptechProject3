﻿namespace CollegeManagement.DTO.DepartmentsDTO
{
    public class DepartmentDataDTO
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Info { get; set; }
        public int FacultyCount { get; set; }
    }
}
