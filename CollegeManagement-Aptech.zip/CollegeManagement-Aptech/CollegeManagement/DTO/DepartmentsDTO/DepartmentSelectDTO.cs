﻿namespace CollegeManagement.DTO.DepartmentsDTO
{
    public class DepartmentSelectDTO
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
