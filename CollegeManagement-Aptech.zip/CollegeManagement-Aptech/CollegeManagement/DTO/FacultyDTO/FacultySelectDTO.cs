﻿namespace CollegeManagement.DTO.FacultyDTO
{
    public class FacultySelectDTO
    {
        public int ID { get; set; }
        public string? Name  { get; set; }
    }
}
